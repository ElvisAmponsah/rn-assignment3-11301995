const CategoryMockUp=[
    {
        id: 0,
        title: "Exercise",
        task: "12 tasks",
        image: require('../../assets/woman.png')
    },
    {
        id: 1,
        title: "Study",
        task: "12 tasks",
        image: require('../../assets/man.png')
    },
    {
        id: 2,
        title: "Code",
        task: "12 tasks",
        image: require('../../assets/woman.png')
    },
    {
        id: 3,
        title: "School",
        task: "12 tasks",
        image: require('../../assets/man.png')
    },
    
]
export default CategoryMockUp