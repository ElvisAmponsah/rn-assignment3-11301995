const OngoingTaskMockUp =[
    {
        id : 0,
        text : "Web Development"
    },
    {
        id : 1,
        text : "Mobile App Development"
    },
    {
        id : 2,
        text : "Desktop App Development"
    },
   
    
    
]
export default OngoingTaskMockUp